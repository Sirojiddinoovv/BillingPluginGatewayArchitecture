rootProject.name = "Billing"
