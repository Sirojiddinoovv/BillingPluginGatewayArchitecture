package uz.nodir.billing.service.adapter

import mu.KotlinLogging
import org.springframework.stereotype.Component
import uz.nodir.billing.model.property.PluginProperty
import uz.nodir.paycommon.adapter.PaymentAdapter
import uz.nodir.paycommon.enums.Processor
import java.util.concurrent.ConcurrentHashMap


/**
@author: Nodir
@date: 22.09.2025
@group: Meloman

 **/

@Component
class PaymentPluginRegistry(
    private val props: PluginProperty
) {
    private val log = KotlinLogging.logger {}

    private val adapters: MutableMap<Processor, PaymentAdapter> = ConcurrentHashMap()

    fun register(adapter: PaymentAdapter) {
        val key = adapter.id
        val prev = adapters.put(key, adapter)
        if (prev == null)
            log.info("Registered adapter '{}'", key)

        else log.info("Replaced adapter '{}'", key)
    }

    fun getIfEnabled(id: Processor): PaymentAdapter? {

        val impl = adapters[id]
        return if (impl != null && props.isEnabled(id)) impl else null
    }

    fun listIds(): List<Processor> =
        adapters
            .keys
            .filter { props.isEnabled(it) }
            .sorted()

    fun clear() {
        adapters.clear()
    }
}