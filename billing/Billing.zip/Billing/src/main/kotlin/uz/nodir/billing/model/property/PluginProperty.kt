package uz.nodir.billing.model.property

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.cloud.context.config.annotation.RefreshScope
import uz.nodir.paycommon.enums.Processor


/**
@author: Nodir
@date: 22.09.2025
@group: Meloman

 **/

@RefreshScope
@ConfigurationProperties(prefix = "internal.plugins")
open class PluginProperty(
    var dir: String = "./plugins",
    var watch: Boolean = true,
    var adapters: Adapters = Adapters()
) {


    class Adapters(
        var enabled: List<Processor> = emptyList(),
        var disabled: List<Processor> = emptyList()
    ) {
        override fun toString(): String {
            return "Adapters(enabled=$enabled, disabled=$disabled)"
        }
    }


    fun isEnabled(id: Processor): Boolean {
        return if (adapters.enabled.isNotEmpty()) {
            adapters.enabled.any { it == id }
        } else {
            adapters.disabled.none { it == id }
        }
    }

    override fun toString(): String {
        return "PluginProperty(dir='$dir', watch=$watch, adapters=$adapters)"
    }


}